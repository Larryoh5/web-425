export interface IPerson {
    firstName: string;
    lastName: string;
}